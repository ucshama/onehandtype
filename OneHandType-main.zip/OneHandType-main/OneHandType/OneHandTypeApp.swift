//
//  OneHandTypeApp.swift
//  OneHandType
//
//  Created by Gabi Garcia on 2/24/23.
//

import SwiftUI

@main
struct OneHandTypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
